﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace MyUWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void Speak_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            String sURL = Url_Box.Text;
            if (sURL.IndexOf("http://") == -1)
            {
                sURL = "http://" + sURL;
            }

            try
            {
                Url_Box.Text = sURL;
                Uri webURL = new Uri(sURL);
                WebBrowser.Navigate(webURL);
            }
            catch(Exception)
            {
                throw;
            }
        }

        private void WebBrowserNavigationStarting(WebView sender, WebViewNavigationStartingEventArgs args)
        {
            WebBrowserProgress.IsActive = true;
        }

        private void WebBrowserNavigationComplete(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            WebBrowserProgress.IsActive = false;
        }
    }
}
