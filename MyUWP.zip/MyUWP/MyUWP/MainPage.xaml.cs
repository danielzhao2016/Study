﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.SpeechSynthesis;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace MyUWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        SpeechSynthesizer speechSynthesizer;
        public MainPage()
        {
            this.InitializeComponent();
            speechSynthesizer = new SpeechSynthesizer();
        }

        private async void Speak_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string[] arguments = new string[] { @"window.getSelection().toString();" };
                string text = await WebBrowser.InvokeScriptAsync("eval", arguments);
                Talk(text);
            }
            catch (Exception)
            {
                throw;
            }
            
        }

        private async void Talk(string message)
        {
            var stream = await speechSynthesizer.SynthesizeTextToStreamAsync(message);
            media.SetSource(stream, stream.ContentType);
            media.Play();
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            BrowseUrl();
        }

        private void BrowseUrl()
        {
            String sURL = Url_Box.Text;
            if (sURL.IndexOf("http://") == -1)
            {
                sURL = "http://" + sURL;
            }

            try
            {
                Url_Box.Text = sURL;
                Uri webURL = new Uri(sURL);
                WebBrowser.Navigate(webURL);
            }
            catch (Exception)
            {
                throw;
            }
        }

        private void WebBrowserNavigationStarting(WebView sender, WebViewNavigationStartingEventArgs args)
        {
            WebBrowserProgress.IsActive = true;
        }

        private void WebBrowserNavigationComplete(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            WebBrowserProgress.IsActive = false;
        }

        private void Url_Box_PreviewKeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key.ToString() == "Enter")
            {
                BrowseUrl();
            }
        }

        private async System.Threading.Tasks.Task Get_HTML_ClickAsync()
        {
            string webText = await WebBrowser.InvokeScriptAsync("eval", new string[] { "document.documentElement.outerHTML;" });


            TextOutput.Text = webText;
        }

        private async void Get_HTML_Click(object sender, RoutedEventArgs e)
        {
            await Get_HTML_ClickAsync();
        }
    }
}
